# Atlas: Next-Generation Desktop File Manager

An ultra-refined, high-performance desktop file manager interface inspired by Atlas File Manager and macOS Finder / NeXT, featuring cascading Miller Columns, multi-tab browsing, responsive grid/list/compact modes, quick file previews, a command palette (`Ctrl+K`), and a modular mock filesystem architecture designed for seamless Tauri 2 + Rust integration.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and UX choices have been established based on your preferences and the project specifications:

- **Confirmed Theme & Visual Identity**: **Atlas Obsidian** — Deep graphite and obsidian canvas (`#0D0F12`, `#14171C`, `#1A1D24`), razor-sharp hairline borders (`#262A33`), crisp muted typography, and restrained electric cyan/cobalt active accents (`#38BDF8` / `#2563EB`).
- **Confirmed Default Browsing View**: **Miller Columns** — Multi-level cascading column hierarchy that allows traversing nested paths (`Documents → Projects → Applet → Assets`) with synchronized scroll and keyboard column traversal. Grid, List, and Compact views are instantly switchable via toolbar/shortcuts (`Ctrl+1`, `Ctrl+2`, `Ctrl+3`, `Ctrl+4`).
- **Confirmed Mock Filesystem Dataset**: **Comprehensive Hybrid Workspace** — Pre-populated with realistic folders and rich file types (TypeScript/Rust codebases, SVG/PNG assets, MP4 videos, MP3 audio stems, PDFs, markdown specs, spreadsheets, zip archives) with complete metadata (size, dimensions, line counts, timestamps).
- **Architecture Strategy for Tauri 2 / Rust Backend**: Clean separation between UI layers, Zustand global state, and an asynchronous `FileSystemService` interface. UI never touches Node or pseudo-browser disk APIs; swapping in Tauri invoke commands will only require swapping the service implementation.

---

### 1. Overview & Core Concept

- **What It Does**: A keyboard-first, native-feeling desktop file manager providing full directory navigation, multi-tab management, live filterable search, detailed file inspector/preview panels, breadcrumb path editing, background operation queues (copy, cut, paste, rename, duplicate, delete), and an extensible command palette.
- **Target Audience / Persona**: Power users, developers, software engineers, and digital creators who require fast, high-density file navigation with minimal clutter, instant previews, and fluid keyboard control.
- **Key Value**: Replaces clumsy web-style file dashboards with an authentic desktop-grade application experience featuring Miller columns, drag-and-drop file organization, sub-200ms micro-interactions, and zero dead clicks.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Hierarchical Miller Column Traversal**:
   - User clicks a folder or presses `Right Arrow` → A new right-hand column opens smoothly showing child contents.
   - User selects an asset (e.g. `mockup_screen.png` or `main.rs`) → The final column or right-side Inspector displays an instant high-fidelity preview with file dimensions, mime-type, and actions.
2. **Multi-Tab Workspace Workflow**:
   - User presses `Ctrl+T` or clicks `+` in the window title bar → A new tab is instantiated with current or home location.
   - User can switch tabs (`Ctrl+Tab`), duplicate tabs, or close tabs (`Ctrl+W`), with tab history (back/forward) maintained independently per tab.
3. **Command Palette (`Ctrl+K`)**:
   - Instant spotlight-style modal with fuzzy filtering across navigation targets ("Go to Downloads", "Go to Projects"), view mode switches ("Switch to Miller Columns", "Switch to Compact List"), file actions ("Create New Folder", "Toggle Hidden Files"), and system settings.
4. **Desktop File Operations & Queue**:
   - Selecting files and pressing `Ctrl+C` / `Ctrl+X` / `Ctrl+V` or dragging items between columns triggers real mock file operations with an active transfer status bar / toast queue displaying simulated transfer velocity and cancel controls.
5. **Advanced Filterable Search (`Ctrl+F`)**:
   - Instant live search overlay filtering by name, extension (`.ts`, `.rs`, `.png`, `.pdf`), size bracket, or date modified, with highlighted matching substrings.

#### Visual Identity & Theme
- **Aesthetic Direction**: Functionalist, industrial-precision desktop software (Atlas Native aesthetic). No soft pastel cards, no AI slop pill badges, no garish gradients.
- **Color Palette (Atlas Obsidian)**:
  - Deep Canvas: `#0B0D10` (window background), `#12151A` (sidebar & toolbars)
  - Surface & Columns: `#161A21` (file column surface), `#1C212B` (hover), `#222836` (selected item)
  - Hairline Borders: `#252B38` (clean 1px structural dividers)
  - Text Tokens: `#F1F5F9` (primary high-contrast text), `#94A3B8` (secondary metadata), `#64748B` (muted hotkeys)
  - Focus & Accents: `#38BDF8` (subtle focus ring and active indicator), `#3B82F6` (selection highlight)
- **Typography & Hierarchy**:
  - Interface Font: `Plus Jakarta Sans` or modern desktop system UI font stack with optical compensation.
  - Telemetry & File Attributes: `JetBrains Mono` / tabular numbers (`tabular-nums`) for byte sizes, dates, and column headers.
  - High information density: 32px row heights for list/compact views, 64px–80px thumbnail tiles for grid views.
- **Interactive Feedback & Motion**:
  - Restrained transitions (120ms–180ms ease-out) for column slide-ins, tab switches, and context menu appearances.
  - Native-style cursor hints, hover backgrounds, and drag-and-drop ghost indicators.

---

### 3. Key Product Decisions & Trade-Offs

- **Zustand Store + Pure Service Interface**:
  - *Chosen Approach*: Decouple all filesystem operations (`listDirectory`, `createFolder`, `renameItem`, `moveItem`, `deleteItem`, `searchFiles`) into a mock `FileSystemService` interface driven by an in-memory mutable virtual tree.
  - *Why*: Direct 1:1 parity with the future Rust Tauri IPC commands. When migrating to Tauri, only `FileSystemService.ts` will be replaced with `@tauri-apps/api/core` invoke calls, leaving 100% of the UI components and Zustand stores intact.
- **Miller Columns as Primary Navigation Engine**:
  - *Chosen Approach*: Fully functional multi-column sliding viewport with independent vertical scroll containers for each directory depth.
  - *Why*: It offers the fastest path navigation for nested folder structures without back-and-forth clicking, adhering directly to Atlas File Manager's defining user experience.
- **Multi-View Engine (Miller, Grid, List, Compact)**:
  - *Chosen Approach*: Modular view renderers controlled by a unified selection and keyboard handler.
  - *Why*: Different workflows demand different densities: media creators need thumbnail grids; systems engineers need compact tabular lists; directory navigators need Miller columns.
- **Rich In-App Previews (Code, Images, Audio, Video, Markdown, Docs)**:
  - *Chosen Approach*: Tailored preview cards in the right Inspector panel that show simulated syntax-highlighted code lines, playable HTML5 audio waveform mocks, SVG/image previews, and structured document metadata.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

#### System Architecture & Component Hierarchy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        App Window Root Layout                          │
│ ┌────────────────────────────────────────────────────────────────────┐ │
│ │ Window Titlebar: Window Controls, Tabs Bar (+ New Tab, Close, Drag)│ │
│ ├────────────────────────────────────────────────────────────────────┤ │
│ │ Navigation Toolbar: Back/Fwd, Breadcrumb Address Bar, View Toggles │ │
│ ├──────────────────────┬─────────────────────────────┬───────────────┤ │
│ │                      │      Main View Engine       │               │ │
│ │ Collapsible Sidebar  │  ┌────────────────────────┐ │ Inspector /   │ │
│ │  - Favorites/Home    │  │ Miller Columns View /   │ │ Info Panel    │ │
│ │  - Quick Access      │  │ Grid View /             │ │  - Preview   │ │
│ │  - Drives & Storage  │  │ List View /             │ │  - Metadata  │ │
│ │  - Trash & Settings  │  │ Compact View            │ │  - Attributes│ │
│ │                      │  └────────────────────────┘ │               │ │
│ ├──────────────────────┴─────────────────────────────┴───────────────┤ │
│ │ Status Bar: Item Count, Selected Count, Free Disk Space, Op Queue  │ │
│ └────────────────────────────────────────────────────────────────────┘ │
│ Overlays: Command Palette (Ctrl+K) · Context Menus · Confirm Dialogs   │
└────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
       ┌────────────────────────────────────────────────────────┐
       │             Zustand Application State Store            │
       │  - Active Tab State (path, history, selection, view)   │
       │  - File Operations Queue (copy, cut, move, status)     │
       │  - UI State (sidebar open, preview open, theme, modal) │
       │  - Search Query & Filter Criteria                      │
       └────────────────────────────┬───────────────────────────┘
                                    │
                                    ▼
       ┌────────────────────────────────────────────────────────┐
       │             Mock FileSystemService Interface           │
       │  - getDirectory(path)      - search(query, filters)    │
       │  - createFolder(path, name)- deleteItem(path)          │
       │  - moveItem(src, dest)     - renameItem(path, newName) │
       │  (Ready for 1:1 drop-in Rust Tauri 2 Invoke Handlers)  │
       └────────────────────────────────────────────────────────┘
```

#### Core Data Entities
```typescript
interface FileItem {
  id: string;
  name: string;
  path: string;
  type: 'folder' | 'file';
  extension?: string;
  size: number; // bytes
  modifiedAt: string;
  createdAt: string;
  mimeType?: string;
  isStarred?: boolean;
  isHidden?: boolean;
  thumbnailUrl?: string;
  previewType?: 'image' | 'video' | 'audio' | 'code' | 'text' | 'archive' | 'pdf';
  codeContent?: string;
  dimensions?: { width: number; height: number };
}

interface TabState {
  id: string;
  title: string;
  path: string;
  history: string[];
  historyIndex: number;
  viewMode: 'miller' | 'grid' | 'list' | 'compact';
  selectedIds: string[];
  sortBy: 'name' | 'size' | 'modified' | 'type';
  sortOrder: 'asc' | 'desc';
}
```

#### Planned Execution Steps (Post-Approval)
1. Install `zustand` to support clean global application state and tab synchronization.
2. Build `FileSystemService` with initial hybrid filesystem mock data (Development, Assets, Documents, Media, System drives).
3. Create atomic UI components: Breadcrumb Bar, Window Header with Tab Bar, Sidebar, Toolbar, Status Bar.
4. Implement Miller Columns navigation engine with horizontal scrolling and multi-depth path loading.
5. Implement Grid, Detailed List, and Compact View modes with sorting and multi-selection.
6. Build Right Inspector Panel with dynamic file previews (syntax highlighted code, image viewer, audio player, document info).
7. Build Command Palette (`Ctrl+K`), custom cursor-positioned Context Menus, Keyboard Shortcut handlers, and Operation Queue dialog.
8. Validate application compilation and linting.
